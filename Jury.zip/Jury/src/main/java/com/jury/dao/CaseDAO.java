package com.jury.dao;

import java.util.List;

import com.jury.model.CaseTypes;

public interface CaseDAO {
	public List<CaseTypes> getCaseTypes();
}