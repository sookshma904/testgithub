package com.jury.service;
import java.util.List;

import com.jury.model.CaseTypes;
import com.jury.model.User;
public interface CaseService {
	public List<CaseTypes> getCaseTypes();
}
